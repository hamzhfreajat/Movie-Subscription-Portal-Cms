<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();

// define table fields
	$rating = array(
		'rating_id' => array(
			'type' => 'INT',
			'constraint' => 11,
			'unsigned' => TRUE,
			'auto_increment' => TRUE
		),
		'type' => array(
			'type' => 'VARCHAR',
			'constraint' => 255,
			'null' => TRUE
		),
		'rate' => array(
			'type' => 'INT',
			'constraint' => 11,
			'null' => TRUE
		),
		'user_id' => array(
			'type' => 'INT',
			'constraint' => 11,
			'null' => TRUE
		),
		'movie_or_series_id' => array(
			'type' => 'INT',
			'constraint' => 11,
			'null' => TRUE
		),
		'comment' => array(
			'type' => 'LONGTEXT',
			'null' => TRUE
		)
	);
	$CI->dbforge->add_field($rating);
	// define primary key
	$CI->dbforge->add_key('rating_id', TRUE);
	// create table
	$CI->dbforge->create_table('rating');



	$is_trendy = array(
	    'is_trendy' => array(
	        'type' => 'int',
	        'constraint' => 11,
	        'null' => TRUE
	    )
	);
	$CI->dbforge->add_column('movie', $is_trendy);



// INSERT VERSION NUMBER INSIDE SETTINGS TABLE
$settings_data = array( 'description' => '2.5');
$CI->db->where('type', 'version');
$CI->db->update('settings', $settings_data);
?>
